import { scoring } from "./scoring.js";

// Given shuffle algorithm for picking words in a bag
function shuffle(array) {
  // Fisher-Yates shuffle, used for random decoder cipher below
  let m = array.length;

  // While there remain elements to shuffle…
  while (m) {
    // Pick a remaining element…
    let i = Math.floor(Math.random() * m--);

    // And swap it with the current element.
    let t = array[m];
    array[m] = array[i];
    array[i] = t;
  }

  return array;
}

export class Game {
  // Private fields
  #bag; // The bag of tiles
  #grid; // The game board

  constructor() {
    this.#bag = this.#initBag();
    this.#grid = this.#initGrid();
  }

  #initBag() {
    // TASK #2: Implement the initBag method
    let bag =[];
    const bags ={ 'a': 9, 'b': 2, 'c': 2, 'd': 4, 'e': 12, 'f': 2, 'g': 3, 'h': 2, 'i': 9,'j': 1, 'k': 1, 'l': 4, 'm': 2, 'n': 6, 'o': 8, 'p': 2, 'q': 1, 'r': 6, 's': 4, 't': 6, 'u': 4, 'v': 2, 'w': 2, 'x': 1, 'y': 2, 'z': 1, '*': 2 };
    for (let l in bags)
      for(let i=0;i<bags[l];++i)
        bag.push(l);
    bag =shuffle(bag);
    return bag;
  }

  #initGrid() {
    // TASK #3: Implement the initGrid method
    const grid = [];
    grid.push(undefined);
    for(let i=1;i<=15;++i)
    {
      let tmp =[];
      tmp.push(undefined);
      for(let j=1;j<=15;++j)
        tmp.push(null);
      grid.push(tmp);
    }
    return grid;
  }

  /**
   * This function removes the first n tiles from the bag and returns them. If n
   * is greater than the number of remaining tiles, this removes and returns all
   * the tiles from the bag. If the bag is empty, this returns an empty array.
   * @param {number} n The number of tiles to take from the bag.
   * @returns {Array<string>} The first n tiles removed from the bag.
   */
  takeFromBag(n) {
    // TASK #5: Implement the takeFromBag method
    if (n>this.#bag.length())
      return this.#bag;
    else
    {
      tmp=[];
      for (let i=0;i<n;++i)
        tmp.push(this.#bag.shift());
      return tmp;
    }
  }

  #canBePlacedOnBoard(word, position, direction) {
    // TASK #4.1: Implement the #canBePlacedOnBoard method
    let x =Number(position.x);
    let y= Number(position.y);
    console.log(x,y);
    if (x<=0 || x>15 || y<=0 ||y>15)
      return false;
    if(this.#grid[x][y]===undefined)
      return false;
    if (direction==='true')
      if (x+word.length-1>15)
        return false;
    else 
      if (y+word.length-1>15)
        return false;
    for (let i =0;i<word.length;++i)
      if (direction)
        if (this.#grid[x+i][y]!==null)
          return false;
      else 
        if (this.#grid[x][y+i]!==null)
          return false;
    return true;
  }

  #placeOnBoard(word, position, direction) {
    // TASK #4.2: Implement the #placeOnBoard method
    let x =Number(position.x);
    let y= Number(position.y);
    for (let i =0;i<word.length;++i)
      if (direction==='true')
        this.#grid[x+i][y]=word[i];
      else 
        this.#grid[x][y+i]=word[i];
  }

  /**
   * This function will be called when a player takes a turn and attempts to
   * place a word on the board. It will check whether the word can be placed at
   * the given position. If not, it'll return -1. It will then compute the score
   * that the word will receive and return it, taking into account special
   * positions.
   *
   * @param {string} word The word to be placed.
   * @param {Object<x|y, number>} position The position, an object with
   * properties x and y. Example: { x: 2, y: 3 }.
   * @param {boolean} direction Set to true if horizontal, false if vertical.
   * @returns {number} The score the word will obtain (including special tiles),
   * or -1 if the word cannot be placed.
   */
  playAt(word, position, direction) {
    // We first check if the word can be placed
    if (!this.#canBePlacedOnBoard(word, position, direction)) {
      return -1;
    }
    // Place the word on the board
    this.#placeOnBoard(word, position, direction);
    // Compute the score
    return scoring.score(word, position, direction);
  }

  render(element) {
    // TASK #7: Implement the render method
    let e =element;
    while(e.firstChild){
      e.removeChild(e.firstChild);
  }
    for (let i=1;i<=15;++i)
      for (let j=1;j<=15;++j)
      {
        let tmp =document.createElement('div');
        tmp.innerText=this.#grid[i][j];
        tmp.classList.add("grid-item");
        let s= scoring.label(i,j);
        if (s!="") 
          tmp.classList.add(s);
        e.appendChild(tmp);
      }
  }

  // These functions are used by the auto-grader to check your implementation.
  // You can ignore them as part of the rest of the implementation, but feel
  // free to use them for your own testing purposes.
  testGetBag() {
    return this.#bag;
  }

  testGetGrid() {
    return this.#grid;
  }

  testCanBePlacedOnBoard(word, position, direction) {
    return this.#canBePlacedOnBoard(word, position, direction);
  }

  testPlaceOnBoard(word, position, direction) {
    this.#placeOnBoard(word, position, direction);
  }
}
